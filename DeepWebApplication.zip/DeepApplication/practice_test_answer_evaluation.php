<?php
session_start();
ob_start();
if (!isset($_SESSION['email'])) {
  header("location:signin.php");
}
if (isset($_POST['logout'])) {

  header("location:signin.php");
}
include('inc/connection.php');
error_reporting(0);
/*
==============================================================================

*/
$sql = "SELECT count(id) as Que_id FROM `practice_test_questions` WHERE category_id='" . $_SESSION['cat'] . "'";
$max = mysqli_query($conn, $sql);
if (mysqli_num_rows($max) > 0) {
  $Total_value = mysqli_fetch_assoc($max);
  // $Total_value['Que_id'].'<br>';
  $random = rand(1, $Total_value['Que_id']);
  //echo $random;
}
/*
==============================================================================
*/
?>
<head>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src='https://unpkg.co/gsap@3/dist/gsap.min.js'></script>
  <script src="scripts/progressbar.js"></script>
  <script src="js/backtotop.js"></script>
  <link href="css/progressbar.css" rel="stylesheet" />
<?php
  $select_category = "SELECT `subject_name` FROM  `subject` WHERE id='" . $_SESSION['cat'] . "'";
  $catres = mysqli_query($conn, $select_category);
  if (mysqli_num_rows($catres) > 0) {
    $YourCATEGORY = mysqli_fetch_assoc($catres);
    $YourCATEGORY['subject_name'];
    $_SESSION['selected_cat'] = $YourCATEGORY['subject_name'];
  }
?>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/style.css">
<div class="container-fluid">
  <div class="box" style="height: auto;width: 100%;  margin-bottom:20px;position:absolute; left:0px; ">
    <div id="timer"></div><br>
    <p class="uname">Username:<span class="username"> <?php echo $_SESSION['fname']; ?></span></p>
    <p class="catname">Subject:
      <span style="color:orange;"> <?php echo $YourCATEGORY['subject_name']; ?></span>
    </p>
  </div>
  <br><br>
  <div class="container">
    <!--Start of Container-->
    <br>
    <?php
    //Fetching Questions In Random Manner 
    $select_que = "SELECT p.* FROM `practice_test_questions` p WHERE p.subject_id = " . $_SESSION['cat'] . " AND NOT p.id IS NULL AND NOT EXISTS (SELECT NULL FROM learn_ques v WHERE p.id= v.ques_id AND v.rollno= '" . $_SESSION['rollno'] . "' limit 8) order by rand() LIMIT 1";
    $res = mysqli_query($conn, $select_que);
    $i = 1;
    if (mysqli_num_rows($res) > 0) {
      while ($rs = mysqli_fetch_assoc($res)) {
        $quest['question'] = $rs;
    ?>
        <!--==============================================================================-->
        <form action="answer.php" method="post" id="quiz">
          <!--Form Starts Here-->
          <!--Fetching Questions in Table-->
          <table class="table table-bordered table-responsive" id="mytable" style="width:100%; margin-top:0px;">
            <!--Table Starts Here-->
            <thead style="width: 100px;">
              <!--Start of Table Header-->
              <tr class="primary" style="width:98%;">
                <th style="color:black; font-size: 1em; width:98%;">
                  &nbsp;<?php echo $rs['question']; ?>
                </th>
                <!--ECHOING QUESTION ON TABLE HEADER-->
              </tr>
            </thead>
            <!--END OF TABLE HEAD-->
            <tbody>
              <!--START OF TABLE BODY-->
              <?php if (isset($rs['ans1'])) { ?>
                <tr class="info">
                  <td> &nbsp;<input type="radio" value="<?php echo $rs['ans1']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp <?php echo $rs['ans1']; ?>
                    <?php } ?>
                  <!--ECHOING FIRST ANSWER-->
                  <?php if (isset($rs['ans2'])) { ?>
                    &nbsp;<input type="radio" value="<?php echo $rs['ans2']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans2']; ?>
                  <?php } ?>
                  <!--ECHOING SECOND ANSWER-->
                  <?php if (isset($rs['ans3'])) { ?>
                    &nbsp;<input type="radio" value="<?php echo $rs['ans3']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans3']; ?>
                  <?php } ?>
                  <!--ECHOING THIRD ANSWER-->
                  <?php if (isset($rs['ans4'])) { ?>
                    &nbsp;<input type="radio" value="<?php echo $rs['ans4']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans4']; ?>
                  </td>
                </tr>
              <?php } ?>
              <!--ECHOING FOURTH ANSWER-->
              <input type="radio" value="no_answer" checked="checked" style="display:none;" name="<?php echo $rs['id']; ?>" />
            <?php
            $i++;
            //i will iterat untill it will get questions
          }
            ?>
          <?php } ?>
            </tbody>
            <!--END OF TABLE BODY-->
          </table>
          <center><input type="submit" value="submit Quiz" id="submit" class="btn btn-success" /></center>
          <!--End of Form-->
        </form>


        <progress id="file" value="<?php  echo $_SESSION['qcount']; ?>" max="5" style="width:100%; height:50px;border-radius:0px;"> </progress> 


        <a id="back2Top" title="Back to top" href="#" style="float: right;">&#10148;</a>
        <script type="text/javascript">
          /*
==============================================================================
Script For Timer

*/
        </script>

        <script>
          var total_seconds = 60;
          var c_minutes = parseInt(total_seconds / 60);
          var c_seconds = parseInt(total_seconds % 60);

          function CheckTime() {
            document.getElementById('timer').innerHTML = 'TIME LEFT:' + ' ' + c_minutes + '   ' + 'min' + ' ' + c_seconds + '  ' + 'sec';
            if (total_seconds <= 30) {
              {
                timer.style.color = '#f90';
                //
              }
            }
            if (total_seconds <= 10) {

              {
                timer.style.color = 'red';
                //
              }
            }
            if (total_seconds <= 0) {

              //alert("Sorry your time is over!!!");
              $("#submit").click();
              //this code is used for submitting form it requires Jquery CDN 




            } else {
              total_seconds = total_seconds - 1;
              c_minutes = parseInt(total_seconds / 60);
              c_seconds = parseInt(total_seconds % 60);
              setTimeout("CheckTime()", 1000);
            }
          }
          setTimeout("CheckTime()", 1000);
        </script>
        <!--
==============================================================================
   -->

  
  </div>
  <!--End Of Container-->
   <!-- Progress BAR Start-->

       

</div>
<!--End Of Container-Fluid-->
<!--
=============================================================================
-->


</body>
<!--

==============================================================================
				SCRIPT STARTS FOR MAKING TD CLICKABLE
-->
<script type="text/javascript">
  /*
		this script is used for making whole td clickable  
  	*/
  $('.table tbody tr td').click(function(event) {
    if (event.target.type !== 'radio') {
      $(':radio', this).trigger('click');
    }
  });
</script>
<!--
==============================================================================
  -->

</html>