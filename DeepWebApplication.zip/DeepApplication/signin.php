<?php
session_start();
if (isset($_SESSION['email'])); {
    session_unset();
}

include("inc/connection.php");
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="DEEP IAS COACHING">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Deep IAS</title>

   



    <!-- Bootstrap core CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- Custom styles for this template -->
    <link href="css/signin.css" rel="stylesheet">
    <script src="scripts/loginvalid.js"></script>
	 <!--End Of Validation Script-->
  	<script src="scripts/emailpassvalid.js"></script>
    <meta charset="UTF-8">
</head>

<body class="text-center">


    <!--Div Start for Generating Popup Error Message-->
    <div class="modal fade" id="Failed" role="dialog">
        <div class="modal-dialog">
            <!--Start of Model Dialog-->


            <div class="modal-content">
                <!--Start of Model content-->

                <div class="modal-body">
                    <!--Start of model body which shows error message-->
                    <!--Dynamic paragraph which takes value from php variable-->
                    <p id="msg" style="color:black;font-size:25px;" class="text-primary text-center">


                    </p>
                    <!--End of Paragraph-->
                </div>
                <!--End of model body-->

            </div>
            <!--End of model content-->

        </div>
        <!--End of Model Dialog-->
    </div>
    <!--End of Pop up Block-->


    <!--PHP CODE FOR ERROR-->


    <?php



    /*
						if condition for multiple status 
  					*/

    $message = "Loading...";

    if (isset($_GET['status']) and $_GET['status'] == "failed") {
        $message = "Invalid Username/Password!!!";
        /* Condition while inserting username/password if not valid/Authentic it shows this message*/
    }
    if (isset($_GET['status']) and $_GET['status'] == "success") {
        $message = "You are Registered Successfully!!!";
        /* if register form gets this status it will show this message*/
    }


    ?>



    <!--End of PHP CODE FOR ERROR-->

    <script>
        //This script generates the error message on diffrent conditions
        $(document).ready(function() {
            /*  id for message in paragraph */
            $("#msg").html("<?php echo $message; ?>");
            /*
        id of status which is coming from header location in php 
    */
            $('#Failed').modal('show');
            setTimeout("$('#Failed').modal('hide'); ", 4000);

        });
    </script>





    <div class="container">
        <main class="form-signin">
            <form action="login_sub.php" method="post" onsubmit=" return logvalid();">
                <img class="mb-4" src="assets/deeplogo.jpeg" alt="" width="100" height="100">
                <h1 class="h3 mb-3 fw-normal">Please sign in</h1>

                <div class="form-floating">
                <input type="email" class="form-control" id="logemail" name="email" placeholder="Enter your Email">
                    <label for="floatingInput">Email address</label>
                    
                    <!--Div For Showing Error Message-->
                    <div id="logemailchk" class="popup_error">
					    	
					    	
					</div>
					<!--End of Div Error Message-->
                </div>
                <div class="form-floating">
                    <input type="password" id="pass" name="pass" class="form-control"  placeholder="Password">
                    <label for="floatingPassword">Password</label>
                </div>
                <!--Start of Div Showing Error Message-->
                <div id="logpasschk" class="popup_error">
					     	
				</div>
				<!--End of Div Showing Error Message-->

                <div class="checkbox mb-3">
                    <label>
                       	 <!-- <input type="checkbox" onclick="ShowPasslog();">&nbsp;Show Password-->
                        <input type="checkbox" value="remember-me"> Remember me
                    </label>
                </div>
                <input class="w-100 btn btn-outline-info" type="submit" name="login" value="Login">
                <div class="container-fluid" style="margin:10px;">
                <a  href="registration.php" class="w-20 btn btn-success">New User ? Signup</a>
                <input class="w-20 btn btn" type="submit" name="resetpass" value="Forgot Password">
                

                </div>

               
                <p class="mt-5 mb-3 text-muted">&copy; 2017–2022</p>
            </form>
        </main>
    </div>





    

</body>

</html>