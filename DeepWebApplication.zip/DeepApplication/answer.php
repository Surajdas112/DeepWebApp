<?php
include('inc/connection.php');

session_start();
ob_start();

//$_SESSION['userans']= rand(100,10000);

$userAnswerid = array();
$userAnswer = array();

$correct=0;
$incorrect = 0;

foreach ($_POST as $key => $value) {
   

    $userAnswerid[] = $key;




	
    $userAnswer[] = $value;

	


}




$ansquery1 = "SELECT id,LOWER(ans) from practice_test_questions where id =$userAnswerid[0]";

$ansquery1res=mysqli_query($conn,$ansquery1);

if(mysqli_num_rows($ansquery1res) == 1){

	while($ansrs=mysqli_fetch_assoc($ansquery1res))
	{
						
						 $_SESSION['userans'] = $ansrs['LOWER(ans)'];
						 $_SESSION['ques_id'] = $ansrs['id']; 
						
	}}	


foreach ($_POST as $que => $answers)
{
	
	
	

}
// Store User Input in Session Var

$_SESSION['userInputAnswer'] = $userAnswer[0];


if($userAnswer[0] == "no_answer"){
$_SESSION['skip'] = $_SESSION['skip']+1;
$_SESSION['qcount']  = $_SESSION['qcount']+1;

header("location: newRough.php");



}else{

	



if($_SESSION['userans'] === $userAnswer[0]){

	$_SESSION['catid'] = $_SESSION['cat'];

	$_SESSION['qcount']  = $_SESSION['qcount']+1;

	$_SESSION['right']  = $_SESSION['right']+1;

	$_SESSION['learn_array'][] = $_SESSION['ques_id'];
	
	$_SESSION['newqcount'] = $_SESSION['qcount'];

	$correct+=1;


	$userAnswer = "INSERT INTO `practice_test_answers` (`rollno`, `subject_id`, `question_id`, `user_answer`, `is_correct`,`is_notCorrect`)
	VALUES ('".TRIM($_SESSION['rollno'])."',".TRIM($_SESSION['cat']).",".TRIM($_SESSION['qid'])." ,'".TRIM($_SESSION['userInputAnswer'])."',".$correct.",".$incorrect.")";
   
   if ($conn->query($userAnswer) === TRUE) {

	echo "<script>window.location.replace('success.php');</script>";


 
	} else  {          print "Error: " .$userAnswer. "<br>" . $conn->error;                  
  }




	
 
 
	
} 
else{

	$_SESSION['qcount']  = $_SESSION['qcount']+1;
	$_SESSION['wrong']  = $_SESSION['wrong']+1;


	$incorrect+=1;


	$userAnswer = "INSERT INTO `practice_test_answers` (`rollno`, `subject_id`, `question_id`, `user_answer`, `is_correct`,`is_notCorrect`)
	VALUES ('".TRIM($_SESSION['rollno'])."',".TRIM($_SESSION['cat']).",".TRIM($_SESSION['qid'])." ,'".TRIM($_SESSION['userInputAnswer'])."',".$correct.",".$incorrect.")";
   
   if ($conn->query($userAnswer) === TRUE) {

	echo "<script>window.location.replace('wrong.php');</script>";
 
	} else  {   print "Error: " .$userAnswer. "<br>" . $conn->error;                  
  }

	
	}
}


?>
