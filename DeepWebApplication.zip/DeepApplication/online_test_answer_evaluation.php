<?php
include('inc/connection.php');
session_start();

$correct = 0;
$incorrect = 0;
$negative =  1/3;
$score = 0;

$userAnswer;




if (isset($_POST['next']) && !empty(isset($_POST['next']))){

    
  

        // POST next is an array where the user answer is present in index 0
   
   
         foreach ($_POST as $value=> $val) {

          $myanswer[$value] =  $val;


         }

        if($myanswer[$_SESSION["currentQuestion"]] != null){
            
        
        // make user ans in CAPS 
          $_SESSION['userAnswerinCaps']  = ucwords($myanswer[$_SESSION["currentQuestion"]]);


          

          // echo($myanswer[$_SESSION["currentQuestion"]]);

        //    Compare User Answer and  Correct Answer from Question table  

          if ($_SESSION['userAnswerinCaps'] == $_SESSION['correctAnswer']) {
            $correct = 1;
          }
          elseif($_SESSION['userAnswerinCaps'] != $_SESSION['correctAnswer']) {
            $incorrect = 1;
          }

          
          $userAnswer = "INSERT INTO `online_test_answers` (`rollno`, `subject_id`, `question_id`, `user_answer`, `is_correct`,`is_notCorrect`)
           VALUES ('" .TRIM($_SESSION['rollno']). "','" .TRIM($_SESSION['selectedcat'])  . "','".TRIM($_SESSION['qid'])."' ,'" . TRIM($_SESSION['userAnswerinCaps']) ."',".$correct.",".$incorrect.")";
          
          if ($conn->query($userAnswer) === TRUE) {
        
            $_SESSION["currentQuestion"] += 1;
           header('Location:online_test.php');
           } else  {          print "Error: " .$userAnswer. "<br>" . $conn->error;                  
         }

 }else{
  
  ?>
  <script>
  alert('You have not selected any option');
  window.location.href='online_test.php';
  </script>";
          
<?php

 }

}

elseif(isset($_POST['skip'])){$_SESSION["currentQuestion"] += 1; header('Location:online_test.php');}
elseif(isset($_POST['button1'])){$_SESSION["currentQuestion"]=1 ;header('Location:online_test.php');}
elseif(isset($_POST['button2'])){$_SESSION["currentQuestion"]=2 ;header('Location:online_test.php');}
elseif(isset($_POST['button3'])){$_SESSION["currentQuestion"]=3 ;header('Location:online_test.php');}
elseif(isset($_POST['button4'])){$_SESSION["currentQuestion"]=4 ;header('Location:online_test.php');}
elseif(isset($_POST['button5'])){$_SESSION["currentQuestion"]=5;header('Location:online_test.php');  }
elseif(isset($_POST['button6'])){$_SESSION["currentQuestion"]=6;header('Location:online_test.php');  }
elseif(isset($_POST['button7'])){$_SESSION["currentQuestion"]=7;header('Location:online_test.php');  }
elseif(isset($_POST['button8'])){$_SESSION["currentQuestion"]=8;header('Location:online_test.php');  }
elseif(isset($_POST['button9'])){$_SESSION["currentQuestion"]=9;header('Location:online_test.php');  }
elseif(isset($_POST['button10'])){$_SESSION["currentQuestion"]=10;header('Location:online_test.php');  }
elseif(isset($_POST['button11'])){$_SESSION["currentQuestion"]=11;header('Location:online_test.php');  }
elseif(isset($_POST['button12'])){$_SESSION["currentQuestion"]=12;header('Location:online_test.php');  }
elseif(isset($_POST['button13'])){$_SESSION["currentQuestion"]=13;header('Location:online_test.php');  }
elseif(isset($_POST['button14'])){$_SESSION["currentQuestion"]=14;header('Location:online_test.php');  }
elseif(isset($_POST['button15'])){$_SESSION["currentQuestion"]=15;header('Location:online_test.php');  }
elseif(isset($_POST['button16'])){$_SESSION["currentQuestion"]=16;header('Location:online_test.php');  }
elseif(isset($_POST['button17'])){$_SESSION["currentQuestion"]=17;header('Location:online_test.php');  }
elseif(isset($_POST['button18'])){$_SESSION["currentQuestion"]=18;header('Location:online_test.php');  }
elseif(isset($_POST['button19'])){$_SESSION["currentQuestion"]=19;header('Location:online_test.php');  }
elseif(isset($_POST['button20'])){$_SESSION["currentQuestion"]=20;header('Location:online_test.php');  }
elseif(isset($_POST['button21'])){$_SESSION["currentQuestion"]=21;header('Location:online_test.php');  }
elseif(isset($_POST['button22'])){$_SESSION["currentQuestion"]=22;header('Location:online_test.php');  }
elseif(isset($_POST['button23'])){$_SESSION["currentQuestion"]=23;header('Location:online_test.php');  }
elseif(isset($_POST['button24'])){$_SESSION["currentQuestion"]=24;header('Location:online_test.php');  }
elseif(isset($_POST['button25'])){$_SESSION["currentQuestion"]=25;header('Location:online_test.php');  }
elseif(isset($_POST['button26'])){$_SESSION["currentQuestion"]=26;header('Location:online_test.php');  }
elseif(isset($_POST['button27'])){$_SESSION["currentQuestion"]=27;header('Location:online_test.php');  }
elseif(isset($_POST['button28'])){$_SESSION["currentQuestion"]=28;header('Location:online_test.php');  }
elseif(isset($_POST['button29'])){$_SESSION["currentQuestion"]=29;header('Location:online_test.php');  }
elseif(isset($_POST['button30'])){$_SESSION["currentQuestion"]=30;header('Location:online_test.php');  }
elseif(isset($_POST['button31'])){$_SESSION["currentQuestion"]=31;header('Location:online_test.php');  }
elseif(isset($_POST['button32'])){$_SESSION["currentQuestion"]=32;header('Location:online_test.php');  }
elseif(isset($_POST['button33'])){$_SESSION["currentQuestion"]=33;header('Location:online_test.php');  }
elseif(isset($_POST['button34'])){$_SESSION["currentQuestion"]=34;header('Location:online_test.php');  }
elseif(isset($_POST['button35'])){$_SESSION["currentQuestion"]=35;header('Location:online_test.php');  }
elseif(isset($_POST['button36'])){$_SESSION["currentQuestion"]=36;header('Location:online_test.php');  }
elseif(isset($_POST['button37'])){$_SESSION["currentQuestion"]=37;header('Location:online_test.php');  }
elseif(isset($_POST['button38'])){$_SESSION["currentQuestion"]=38;header('Location:online_test.php');  }
elseif(isset($_POST['button39'])){$_SESSION["currentQuestion"]=39;header('Location:online_test.php');  }
elseif(isset($_POST['button40'])){$_SESSION["currentQuestion"]=40;header('Location:online_test.php');  }
elseif(isset($_POST['button41'])){$_SESSION["currentQuestion"]=41;header('Location:online_test.php');  }
elseif(isset($_POST['button42'])){$_SESSION["currentQuestion"]=42;header('Location:online_test.php');  }
elseif(isset($_POST['button43'])){$_SESSION["currentQuestion"]=43;header('Location:online_test.php');  }
elseif(isset($_POST['button44'])){$_SESSION["currentQuestion"]=44;header('Location:online_test.php');  }
elseif(isset($_POST['button45'])){$_SESSION["currentQuestion"]=45;header('Location:online_test.php');  }
elseif(isset($_POST['button46'])){$_SESSION["currentQuestion"]=46;header('Location:online_test.php');  }
elseif(isset($_POST['button47'])){$_SESSION["currentQuestion"]=47;header('Location:online_test.php');  }
elseif(isset($_POST['button48'])){$_SESSION["currentQuestion"]=48;header('Location:online_test.php');  }
elseif(isset($_POST['button49'])){$_SESSION["currentQuestion"]=49;header('Location:online_test.php');  }
elseif(isset($_POST['button50'])){$_SESSION["currentQuestion"]=50;header('Location:online_test.php');  }
elseif(isset($_POST['button51'])){$_SESSION["currentQuestion"]=51;header('Location:online_test.php');  }
elseif(isset($_POST['button52'])){$_SESSION["currentQuestion"]=52;header('Location:online_test.php');  }
elseif(isset($_POST['button53'])){$_SESSION["currentQuestion"]=53;header('Location:online_test.php');  }
elseif(isset($_POST['button54'])){$_SESSION["currentQuestion"]=54;header('Location:online_test.php');  }
elseif(isset($_POST['button55'])){$_SESSION["currentQuestion"]=55;header('Location:online_test.php');  }
elseif(isset($_POST['button56'])){$_SESSION["currentQuestion"]=56;header('Location:online_test.php');  }
elseif(isset($_POST['button57'])){$_SESSION["currentQuestion"]=57;header('Location:online_test.php');  }
elseif(isset($_POST['button58'])){$_SESSION["currentQuestion"]=58;header('Location:online_test.php');  }
elseif(isset($_POST['button59'])){$_SESSION["currentQuestion"]=59;header('Location:online_test.php');  }
elseif(isset($_POST['button60'])){$_SESSION["currentQuestion"]=60;header('Location:online_test.php');  }
elseif(isset($_POST['button61'])){$_SESSION["currentQuestion"]=61;header('Location:online_test.php');  }
elseif(isset($_POST['button62'])){$_SESSION["currentQuestion"]=62;header('Location:online_test.php');  }
elseif(isset($_POST['button63'])){$_SESSION["currentQuestion"]=63;header('Location:online_test.php');  }
elseif(isset($_POST['button64'])){$_SESSION["currentQuestion"]=64;header('Location:online_test.php');  }
elseif(isset($_POST['button65'])){$_SESSION["currentQuestion"]=65;header('Location:online_test.php');  }
elseif(isset($_POST['button66'])){$_SESSION["currentQuestion"]=66;header('Location:online_test.php');  }
elseif(isset($_POST['button67'])){$_SESSION["currentQuestion"]=67;header('Location:online_test.php');  }
elseif(isset($_POST['button68'])){$_SESSION["currentQuestion"]=68;header('Location:online_test.php');  }
elseif(isset($_POST['button69'])){$_SESSION["currentQuestion"]=69;header('Location:online_test.php');  }
elseif(isset($_POST['button70'])){$_SESSION["currentQuestion"]=70;header('Location:online_test.php');  }
elseif(isset($_POST['button71'])){$_SESSION["currentQuestion"]=71;header('Location:online_test.php');  }
elseif(isset($_POST['button72'])){$_SESSION["currentQuestion"]=72;header('Location:online_test.php');  }
elseif(isset($_POST['button73'])){$_SESSION["currentQuestion"]=73;header('Location:online_test.php');  }
elseif(isset($_POST['button74'])){$_SESSION["currentQuestion"]=74;header('Location:online_test.php');  }
elseif(isset($_POST['button75'])){$_SESSION["currentQuestion"]=75;header('Location:online_test.php');  }
elseif(isset($_POST['button76'])){$_SESSION["currentQuestion"]=76;header('Location:online_test.php');  }
elseif(isset($_POST['button77'])){$_SESSION["currentQuestion"]=77;header('Location:online_test.php');  }
elseif(isset($_POST['button78'])){$_SESSION["currentQuestion"]=78;header('Location:online_test.php');  }
elseif(isset($_POST['button79'])){$_SESSION["currentQuestion"]=79;header('Location:online_test.php');  }
elseif(isset($_POST['button80'])){$_SESSION["currentQuestion"]=80;header('Location:online_test.php');  }
elseif(isset($_POST['button81'])){$_SESSION["currentQuestion"]=81;header('Location:online_test.php');  }
elseif(isset($_POST['button82'])){$_SESSION["currentQuestion"]=82;header('Location:online_test.php');  }
elseif(isset($_POST['button83'])){$_SESSION["currentQuestion"]=83;header('Location:online_test.php');  }
elseif(isset($_POST['button84'])){$_SESSION["currentQuestion"]=84;header('Location:online_test.php');  }
elseif(isset($_POST['button85'])){$_SESSION["currentQuestion"]=85;header('Location:online_test.php');  }
elseif(isset($_POST['button86'])){$_SESSION["currentQuestion"]=86;header('Location:online_test.php');  }
elseif(isset($_POST['button87'])){$_SESSION["currentQuestion"]=87;header('Location:online_test.php');  }
elseif(isset($_POST['button88'])){$_SESSION["currentQuestion"]=88;header('Location:online_test.php');  }
elseif(isset($_POST['button89'])){$_SESSION["currentQuestion"]=89;header('Location:online_test.php');  }
elseif(isset($_POST['button90'])){$_SESSION["currentQuestion"]=90;header('Location:online_test.php');  }
elseif(isset($_POST['button91'])){$_SESSION["currentQuestion"]=91;header('Location:online_test.php');  }
elseif(isset($_POST['button92'])){$_SESSION["currentQuestion"]=92;header('Location:online_test.php');  }
elseif(isset($_POST['button93'])){$_SESSION["currentQuestion"]=93;header('Location:online_test.php');  }
elseif(isset($_POST['button94'])){$_SESSION["currentQuestion"]=94;header('Location:online_test.php');  }
elseif(isset($_POST['button95'])){$_SESSION["currentQuestion"]=95;header('Location:online_test.php');  }
elseif(isset($_POST['button96'])){$_SESSION["currentQuestion"]=96;header('Location:online_test.php');  }
elseif(isset($_POST['button97'])){$_SESSION["currentQuestion"]=97;header('Location:online_test.php');  }
elseif(isset($_POST['button98'])){$_SESSION["currentQuestion"]=98;header('Location:online_test.php');  }
elseif(isset($_POST['button99'])){$_SESSION["currentQuestion"]=99;header('Location:online_test.php');  }
elseif(isset($_POST['button100'])){$_SESSION["currentQuestion"]=100;header('Location:online_test.php');  }

   
else{


  echo '<script>alert("Technical error")</script>';
  header('Location:index.php');

}

















// Previous Version COde Switch 
       //$_SESSION["currentQuestion"] += 1;
   






// switch(true)
// {
//     case isset($_POST['next'] ):

      
    
        


        // echo '<script>alert("hvjm")</script>';
  

        // $_SESSION["currentQuestion"] += 1;
        //   header('Location:online_test.php');
       
// 

        // $_SESSION['userAnswerinCaps']  = ucwords($_POST[1]);
    //    Compare User Answer and  Correct Answer from Question table 
// 

          // // echo ($_SESSION['userAnswerinCaps'][0]);
    //      
    // 
          // //  if ($_SESSION['userAnswerinCaps'] == $_SESSION['correctAnswer']) {
          //   // $isCorrect =  1;
          //   // }
          // //  elseif($_SESSION['userAnswerinCaps'] != $_SESSION['correctAnswer']) {
          // //   $isCorrect =  0;
          // //  }
    
          // //  $score =   number_format((float)$correct*2-$incorrect*$negative, 2, '.', '');

          // echo $score;
    // 
    // 
        // // $userAnswer =
        //   // "INSERT INTO `online_test_answers` (`rollno`, `subject_id`, `question_id`, `user_answer`, `is_correct`)
          // --  VALUES ('" .$_SESSION['rollno']. "','" .$_SESSION['selectedcat']  . "','".$_SESSION['qid']."' ,'" . $_SESSION['userAnswerinCaps'] . "',$isCorrect)";
    // 
    // 
        // // if ($conn->query($userAnswer) === TRUE) {
        
       //   $_SESSION["currentQuestion"] += 1;
        // //  header('Location:online_test.php');
//                 
//  
              // // } else {
              // //   print "Error: " .$userAnswer. "<br>" . $conn->error;
              // // }
      //  
      // // 
      // 
      //
    //    break;

     


    //   case  isset($_POST['skip']):
    //     $_SESSION["currentQuestion"] += 1;
    //     header('Location:online_test.php');
    //   break;

    //   default:

    // }

    
   

     
    


//
   
    

          




  // Question Navigators

        
          
 
          

      
          



?>
