<?php
include('inc/connection.php');

session_start();
ob_start();

$_SESSION['userans']= rand(100,10000);

$userAnswerid = array();
$userAnswer = array();

foreach ($_POST as $key => $value) {
   

    $userAnswerid[] = $key;
    $userAnswer[] = $value;

}



$ansquery1 = "SELECT id,ans from practice_test_questions where id =$userAnswerid[0]";

$ansquery1res=mysqli_query($conn,$ansquery1);

if(mysqli_num_rows($ansquery1res) == 1){

	while($ansrs=mysqli_fetch_assoc($ansquery1res))
	{
						
						 $_SESSION['userans'] = ($ansrs['ans']);
						 $_SESSION['ques_id'] = $ansrs['id']; 
						
	}}	


foreach ($_POST as $que => $answers)
{
	
	
	

}

if($userAnswer[0] == "no_answer"){
$_SESSION['skip'] = $_SESSION['skip']+1;
$_SESSION['qcount']  = $_SESSION['qcount']+1;

//header("location: newRough.php");

}else{

if($_SESSION['userans'] === $userAnswer[0]){

	$_SESSION['catid'] = $_SESSION['cat'];

	$_SESSION['qcount']  = $_SESSION['qcount']+1;

	$_SESSION['right']  = $_SESSION['right']+1;

	$_SESSION['learn_array'][] = $_SESSION['ques_id'];
	
	$_SESSION['newqcount'] = $_SESSION['qcount'];
	
 //echo "<script>window.location.replace('success.php');</script>";
 echo "Error: " . $insert . "<br>" . $conn->error;
	
} 
else{

	$_SESSION['qcount']  = $_SESSION['qcount']+1;
	$_SESSION['wrong']  = $_SESSION['wrong']+1;

//	echo "<script>window.location.replace('wrong.php');</script>";
	}
}


?>
