<?php
session_start();
ob_start();
include('inc/connection.php');

if (isset($_SESSION['email']) && !empty($_SESSION['email']) && isset($_SESSION['password']) && !empty($_SESSION['password'])) {
?>

  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="UTF-8">
    <title>Deep IAS Coaching</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css'>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel="stylesheet" href="css/dashboardButton.css" />
    <link rel="stylesheet" href="css/dashboardTable.css" />
    <link rel="stylesheet" href="css/piechart.css" />
    <script src="Scripts/dashboardTable.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>
    <script src="https://code.highcharts.com/modules/pattern-fill.js"></script>
    <script src="https://code.highcharts.com/themes/high-contrast-light.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <link rel="stylesheet" href="css/accountstyle.css">



    <script type="text/javascript">
      function onlineTest() {
        window.location.href = "test_categories.php";
      }

      function onlineClass() {
        window.location.href = "online_class.php";
      }

      function practiceTest() {
        window.location.href = "practice_test_categories.php";
      }
    </script>

  </head>

  <body>
    <!-- partial:index.partial.html -->
    <nav class="navbar navbar-expand-custom navbar-mainbg">
    <div class="navigation">
        <div class="user-box">
          <div class="image-box">
            <img class="pp" src="assets/pp.jpg" height="30"alt="avatar">
          </div>
          <p class="username" style="font-size:1rem; margin-top:15px;"><?php echo $_SESSION['fname'] . " " . $_SESSION['lastname']; ?></p>
        </div>
        <div class="menu-toggle"></div>
        <ul class="menu">
          <li><a href="#">
              <ion-icon name="person-outline"></ion-icon>Profile
            </a></li>
          <li><a href="#">
              <ion-icon name="notifications-outline"></ion-icon>Notification
            </a></li>
          <li><a href="#">
              <ion-icon name="cog-outline"></ion-icon>
              </ion-icon>Settings
            </a></li>
              <li><a href="logout.php">
              <ion-icon name="log-out-outline"></ion-icon>Logout
            </a></li>
        </ul>
      </div>

      <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="width:60px; height:60px;">
        <i id="menu-bars" class="fas fa-bars text-white"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent" style="position: relative;right:0px;">
        <ul class="navbar-nav ml-auto">
          <div class="hori-selector">
            <div class="left"></div>
            <div class="right"></div>
          </div>
          <li class="nav-item active">
            <a class="nav-link" style="color:white;" href="index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:white;" href="online_class.php"><i class="far fa-clone"></i>Online Class</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:white;" href="test_categories.php"><i class="far fa-clone"></i>Online Test</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:white;" href="practice_test_categories.php"><i class="far fa-calendar-alt"></i>Practice Test</a>
          </li>


        </ul>

      </div>
      

    </nav>







    <!--BODY STARTS FROM HERE-->
    <div class="container-fluid">
      <div style="height: 50px;"></div>



      <div class="row">




        <div class="col-md-8 shadow p-3 mb-5 bg-white rounded" id="quotecontainer" style="border:1px solid #13AEB0;">

          <?php
          $quote = "SELECT * FROM dailyquotes where id=1";
          $quoteres = mysqli_query($conn, $quote);
          if (mysqli_num_rows($quoteres) > 0) {

            $YourQuote = mysqli_fetch_assoc($quoteres);
            $myQuote = $YourQuote['quote'];
          }

          ?>
          <h1 style="color:black; text-align: center;">Today's Quote</h1><br>
          <p style="color:black;  text-align: center;"><?php echo $myQuote; ?></p>

        </div>


        <div class="col-md-4 shadow p-3 mb-5 bg-white rounded" style="border: 1px solid #13AEB0;">
          <div class="d-flex justify-content-center">
            <img src="assets/deeplogo.jpeg" height="100px" width="100px" />
          </div>

          <div class="d-flex justify-content-center ">

            <h4>Welcome, <span><?php echo  $_COOKIE['name'] = $_SESSION['fname']; ?></span></h4>

          </div>
          <div class="d-flex justify-content-center">

            <h6>Roll number:- <?php echo $_COOKIE['roll'] = $_SESSION['rollno']; ?></h6>
          </div>
        </div>

      </div>


      <hr style="height:1px; background-color:#13AEB0;" />
    </div>


    <div class="container-fluid" style="text-align:center;">
      <div class="row">

        <div class="col-md-4" style="margin-top:10px;">
          <button onclick="onlineClass()" class="custom-btn btn-5"><span style="font-size: 1.5em;">Online Class</span></button>
        </div>
        <div class="col-md-4" style="margin-top:10px;">
          <button onclick="onlineTest()" class="custom-btn btn-5"><span style="font-size: 1.5em;">Online Test</span></button>
        </div>
        <div class="col-md-4" style="margin-top:10px;">
          <button onclick="practiceTest()" class="custom-btn btn-5"><span style="font-size: 1.5em;">Practice Test</span></button>
        </div>
      </div>
      <hr style="height:1px; background-color:#13AEB0;" />


      <!--User Performance Table-->


      <!--PHP FOR PERFORMANCE TABLE-->


      <?PHP


      $score = "SELECT SUM(`is_correct`) as Correct, SUM(`is_notCorrect`) as Incorrect FROM `online_test_answers` WHERE `rollno`='" . trim($_SESSION['rollno']) . "' AND `subject_id`=2";
      $score_res = mysqli_query($conn, $score);
      if (mysqli_num_rows($score_res) > 0) {

        $your_score = mysqli_fetch_assoc($score_res);
      }

      $score_IR = "SELECT SUM(`is_correct`) as Correct, SUM(`is_notCorrect`) as Incorrect FROM `online_test_answers` WHERE `rollno`='" . trim($_SESSION['rollno']) . "' AND `subject_id`=1";
      $score_res_IR = mysqli_query($conn, $score_IR);
      if (mysqli_num_rows($score_res_IR) > 0) {

        $your_score_IR = mysqli_fetch_assoc($score_res_IR);
      }











      ?>



      <!--End of PHP CODE CODE FOR PERFORMANCE-->


      <h1>Online Test Report</h1>
      <table class="rwd-table">
        <tr>
          <th>Subject</th>
          <th>Correct</th>
          <th>Incorrect</th>
          <th>Total Score</th>

        </tr>
        <tr>
          <td data-th="Subject"><?php echo "INDIAN POLITY"; ?></td>
          <td data-th="Correct"> <?php echo $your_score['Correct']; ?></td>
          <td data-th="Incorrect"> <?php echo $your_score['Incorrect']; ?></td>
          <td data-th="Total Score"> <?php echo number_format(((int)$your_score['Correct'] * 2 - (int)$your_score['Incorrect'] * 1 / 3), 2, '.', ''); ?></td>

        </tr>

        <tr>
          <td data-th="Subject"><?php echo "INTERNATIONAL RELATIONS"; ?></td>
          <td data-th="Correct"> <?php echo $your_score_IR['Correct']; ?></td>
          <td data-th="Incorrect"> <?php echo $your_score_IR['Incorrect']; ?></td>

        </tr>

      </table>

      <!--Pie CHarts-->
      <div></div>


      <div id="chart-wrap" style="width:100%;">


        <figure class="highcharts-figure">
          <div id="container" style="position:absolute;left:0px;  width:100%;"></div>
        </figure>
      </div>
      <?php


      $query = "SELECT * FROM `user_performance` WHERE rollno='T1234'";

      $getData = mysqli_query($conn, $query);
      while ($row = mysqli_fetch_array($getData, MYSQLI_NUM)) {

        $mysubject[] = $row[2];
        $mymrks[] = (int)$row[3];
      ?>
        <script>
          var clrs = Highcharts.getOptions().colors;
          var pieColors = [clrs[2], clrs[0], clrs[3], clrs[1], clrs[4]];
          // Get a default pattern, but using the pieColors above.
          // The i-argument refers to which default pattern to use
          function getPattern(i) {
            return {
              pattern: Highcharts.merge(Highcharts.patterns[i], {
                color: pieColors[i]
              })
            };
          }

          // Get 5 patterns
          var patterns = [0, 1, 2, 3, 4].map(getPattern);




          var chart = Highcharts.chart('container', {
            chart: {
              type: 'pie'
            },

            title: {
              text: 'Student Performance'
            },

            //colors: patterns,

            tooltip: {
              valueSuffix: '%',
              borderColor: '#8ae'
            },

            plotOptions: {
              series: {
                dataLabels: {
                  enabled: true,
                  connectorColor: '#777',
                  format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                },
                point: {
                  events: {
                    click: function() {
                      window.location.href = this.website;
                    }
                  }
                },
                cursor: 'pointer',
                borderWidth: 3
              }
            },

            series: [{
              name: 'Total Marks Bifurcation',
              data: [{
                  name: '<?php echo $mysubject[0]; ?>',
                  y: <?php echo (int)$mymrks; ?>,
                  website: 'www.mart.denpower.org'
                },
                {
                  name: '<?php echo $mysubject[1]; ?>',
                  y: <?php echo (int)$mymrks[1]; ?>,
                  website: 'mart1.denpower.org'
                },
                {
                  name: '<?php echo $mysubject[2]; ?>',
                  y: <?php echo (int)$mymrks[2]; ?>,
                  website: 'mart2.denpower.org'
                },
                {
                  name: '<?php echo $mysubject[3]; ?>',
                  y: <?php echo (int)$mymrks[3]; ?>,
                  website: 'mart3.denpower.org'
                }
              ]
            }],

            responsive: {
              rules: [{
                condition: {
                  maxWidth: 500
                },
                chartOptions: {
                  plotOptions: {
                    series: {
                      dataLabels: {
                        format: '<b>{point.name}</b>'
                      }
                    }
                  }
                }
              }]
            }
          });

          // Toggle patterns enabled
          document.getElementById('patterns-enabled').onclick = function() {
            chart.update({
              colors: this.checked ? patterns : pieColors
            });
          };
        </script>

      <?php
      }
      ?>





      <!--BODY ENDS HERE-->





      <!-- partial -->
      <script src='https://code.jquery.com/jquery-3.4.1.min.js'></script>
      <script src='https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js'></script>
      <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css'></script>
      <script src="./scripts/script.js"></script>
      <script src="scripts/accountscript.js"></script>






  </body>

  </html>

<?php


} else {
?>
  <script>
    alert('Please Login');
    window.location.href = 'signin.php';
  </script>";

<?php
}



?>