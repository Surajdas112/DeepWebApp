<?php
include('inc/connection.php');
session_start();
ob_start();

if (isset($_POST['submit'])) {


	// //echo $folder;
	// $imageFileType = strtolower(pathinfo($_FILES["upload_img"]["name"],PATHINFO_EXTENSION));
	// $fname=date('Ymd').time();
	// $filename=$fname.".".$imageFileType;

	// $tempname=$_FILES['upload_img']['tmp_name'];
	// $folder="upload/".$filename;
	// if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	// && $imageFileType != "gif" ) {
	//     //echo "<p style='color:red'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
	//     $uploadOk = 0;


	// }
	// //else{
	// move_uploaded_file($tempname,$folder);
	$firstname = ucfirst($_POST['fname']);
	if (!preg_match("/^[a-zA-Z ]*$/", $firstname)) {
		$nameErr = "Only letters and white space allowed";
		echo $nameErr;
		echo "<br>";
	}

	$lastname = ucfirst($_POST['lname']);
	if (!preg_match("/^[a-zA-Z ]*$/", $lastname)) {
		$nameErr = "Only letters and white space allowed";
		echo $nameErr;
		echo "<br>";
	}


	$email = strtolower($_POST['email']);
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$emailErr = "Invalid email format";
		echo $emailErr;
	}

	$password = $_POST['pass'];
	if (empty($password)) {

		die('password can not be empty');
	}
	$cpassword = $_POST['cpass'];

	if (empty($cpassword)) {

		die('can not be empty');
	} else {
		$select_query = "SELECT email FROM register WHERE email='" . $email . "'";
		$res1 = mysqli_query($conn, $select_query);
		if (mysqli_num_rows($res1) > 0) {


			

				?>
					<script>
					alert('Email Already Exist');
					window.location.href='registration.php';
					</script>";
									
				<?php


		} else {


			// store the email in session so we can verify otp using email

			$_SESSION['user_email'] =  $email;
			
			// Generate Random OTP

			$otp = rand(1000, 9999);


			$Select_roll = "select `rollno` from `register` ORDER BY id DESC LIMIT 1;";
			$res = mysqli_query($conn, $Select_roll);
			$row = mysqli_fetch_array($res);

			$rollno = $row['rollno'];
			if (mysqli_num_rows($res) > 0) {



				$rollinString = chop($rollno);
				//remove the  first letter of roll no.
				$rollnum = ltrim($rollinString, 'T');
				//convert roll to int
				$rollinInt = (int)$rollnum;
				// increment roll by 1 
				$newAlotedRollNum = $rollinInt + 1;
				//Prefix the T 
				$finalroll = "T" . $newAlotedRollNum;

					

				$insert = "INSERT INTO register(fname,lname,rollno,email,pass,otp,approve) VALUES('$firstname','$lastname','$finalroll
						','$email','$password',$otp,0)";

				if ($conn->query($insert) === TRUE) {



					$to      = $email;
					$subject = 'Account Verification Code : Deep Coaching ';
					$message = "Hello " . $firstname . "     This is your OTP to verify you E-mail   :-" . $otp;
					$header = "From:noreply@mart.denpower.org \r\n";
					$header .= "Cc:noreply@mart.denpower.org \r\n";
					$header .= "MIME-Version: 1.0\r\n";
					$header .= "Content-type: text/html\r\n";

					$retval = mail($to, $subject, $message, $header);

					if ($retval == true) {
						header("Location: ./verify-email.php");
					} else {
						echo "Message could not be sent...";
					}

					header("Location: ./verify-email.php");
				} else {
					echo "Error: " . $insert . "<br>" . $conn->error;
				}
			} else {
				echo "Not insert";
			}
		}
	}
}
