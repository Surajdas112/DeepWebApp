<?php
session_start();
ob_start();
if (!isset($_SESSION['email'])) {
    header("location:signin.php");
}
if (isset($_POST['logout'])) {

    header("location:signin.php");
}
include('inc/connection.php');
error_reporting(0);
/*
==============================================================================

*/
$sql = "SELECT count(id) as Que_id FROM `practice_test_questions` WHERE category_id='" . $_SESSION['cat'] . "'";
$max = mysqli_query($conn, $sql);
if (mysqli_num_rows($max) > 0) {
    $Total_value = mysqli_fetch_assoc($max);
    // $Total_value['Que_id'].'<br>';
    $random = rand(1, $Total_value['Que_id']);
    //echo $random;
}
/*
==============================================================================
*/
?>
        <head>
            <meta charset="UTF-8">
            <title>Deep IAS Coaching</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
            <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css'>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css'>
            <link rel="stylesheet" href="css/style.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
            <script src="js/backtotop.js"></script>
             <?php
            $select_category = "SELECT `subject_name` FROM  `subject` WHERE id='" . $_SESSION['cat'] . "'";
            $catres = mysqli_query($conn, $select_category);
            if (mysqli_num_rows($catres) > 0) {
                $YourCATEGORY = mysqli_fetch_assoc($catres);
                $YourCATEGORY['subject_name'];
                $_SESSION['selected_cat'] = $YourCATEGORY['subject_name'];
            }
            ?>
        </head>
        <body>
            <!-- partial:index.partial.html -->
            <nav class="navbar navbar-expand-custom navbar-mainbg" style="height:80px; position: fixed;top: 0; width: 100%; margin-bottom:50px;">
            <div><img class="logoimage" src="assets/deeplogo.png" alt="" width="50" height="50"></img></div>
                <div style="margin-top:40px; width:80%; display: inline-block; position:fixed; right:2%;">
                    <span style="color:white;"> <?php echo $YourCATEGORY['subject_name']; ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span style="color:white;" id="timer"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <span style="color:white;text-transform: uppercase;" class="username"> <?php echo $_SESSION['fname']; ?></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                     <span style="color:white;"> Difficulty Level: <?php echo $_SESSION['level'];?></span></p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </div>
            </nav>
            <div style="height:50px;"></div>
            <div class="container-fluid" style="margin-top:50px; width:100%; font-size:20px;">
                <div style="text-align:justify; border: 1px solid #13AEB0;">
                    <?php
                                                            $select_que = "SELECT p.* FROM `practice_test_questions` p WHERE p.subject_id = " . $_SESSION['cat'] . " AND NOT p.id IS NULL AND NOT EXISTS (SELECT NULL FROM learn_ques v WHERE p.id= v.ques_id AND v.rollno= '" . $_SESSION['rollno'] . "' limit 8) order by rand() LIMIT 1";
                                                            $res = mysqli_query($conn, $select_que);
                                                            $i = 1;
                                                            if (mysqli_num_rows($res) > 0) {
                                                            while ($rs = mysqli_fetch_assoc($res)) {
                                                                $quest['question'] = $rs;
                            
                    ?>
                
                    <form action="answer.php" method="post" id="quiz">
                        <table style="width:100%;">

                            <tr>

                                <?php

                                // Get the Question ID

                                $_SESSION['qid'] =  $rs['question_id'];

                                //Get The Correct Answwer from the Question Table and Store it as Session Variable to Store Scores
                                $_SESSION['correctAnswer'] = $rs['ans'];

                                ?>

                                <td class="qcontain" style="text-align:justify; padding:10px;"><?php echo $rs['question']; ?></td>

                            </tr>
                            <?php if (isset($rs['ans1'])) { ?>
                                <tr class="info">
                                    <td> &nbsp;<input type="radio" value="<?php echo $rs['ans1']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp <?php echo $rs['ans1']; ?>
                                    <?php } ?>
                                    <!--ECHOING FIRST ANSWER-->
                                    <?php if (isset($rs['ans2'])) { ?>
                                        &nbsp;<input type="radio" value="<?php echo $rs['ans2']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans2']; ?>
                                    <?php } ?>
                                    <!--ECHOING SECOND ANSWER-->
                                    <?php if (isset($rs['ans3'])) { ?>
                                        &nbsp;<input type="radio" value="<?php echo $rs['ans3']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans3']; ?>
                                    <?php } ?>
                                    <!--ECHOING THIRD ANSWER-->
                                    <?php if (isset($rs['ans4'])) { ?>
                                        &nbsp;<input type="radio" value="<?php echo $rs['ans4']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans4']; ?>
                                    </td>
                                </tr>
                            <?php } ?>
                            <!--ECHOING FOURTH ANSWER-->
                            <input type="radio" value="no_answer" checked="checked" style="display:none;" name="<?php echo $rs['id']; ?>" />
                        <?php
                        $i++;
                        //i will iterat untill it will get questions
                    }
                        ?>
                    <?php } ?>
                    </tbody>
                    <!--END OF TABLE BODY-->
                        </table>
                        <center><input type="submit" value="submit Quiz" id="submit" class="btn btn-success" /></center>
                        <!--End of Form-->
                    </form>

                    </table>





                    <script>
                        /*
==============================================================================
Script For Timer

*/

                        var total_seconds = 60;
                        var c_minutes = parseInt(total_seconds / 60);
                        var c_seconds = parseInt(total_seconds % 60);

                        function CheckTime() {
                            document.getElementById('timer').innerHTML = 'TIME LEFT:' + ' ' + c_minutes + '   ' + 'min' + ' ' + c_seconds + '  ' + 'sec';
                            if (total_seconds <= 30) {
                                {
                                    timer.style.color = '#f90';
                                    //
                                }
                            }
                            if (total_seconds <= 10) {

                                {
                                    timer.style.background = 'red';
                                    timer.style.display = (timer.style.display == 'none' ? '' : 'none');
                                    //
                                }
                            }
                            if (total_seconds <= 0) {

                                //alert("Sorry your time is over!!!");
                                document.getElementById("submit").click(); 




                            } else {
                                total_seconds = total_seconds - 1;
                                c_minutes = parseInt(total_seconds / 60);
                                c_seconds = parseInt(total_seconds % 60);
                                setTimeout("CheckTime()", 1000);
                            }
                        }
                        setTimeout("CheckTime()", 1000);
                    </script>
<!--============================================================================== -->
                </div>
              
                    <div  >
                       <!-- <div  class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="10" style="width:<?php // echo $_SESSION['qcount'];?>%"> -->
                       <div>
                       <!-- <div class="progress-bar" role="progressbar"  aria-valuemax="10" style= " height:20px;width:<?php //echo $_SESSION['qcount'];?>%"> -->
                          
<progress id="file" value="<?php echo $_SESSION['qcount'];?>" max="10" style="width:100%; height:50px;border-radius:0px;">  </progress>  
                        </div>   
                    
                    </div>
                    </div>
                
            </div>




        </body>