<?php
$host="localhost";
$user="root";
$pass="";
$db="deep_db";
$conn=mysqli_connect($host,$user,$pass,$db);
if($conn!=true){
	die("connection failed");
}
else{
	//echo"connected";
}


?>
