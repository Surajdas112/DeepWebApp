<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Deep IAS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel='stylesheet' href='https://bootswatch.com/5/lux/bootstrap.min.css'>
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css'>
<link rel='stylesheet' href='https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css'><link rel="stylesheet" href="./style.css">
<link rel="stylesheet" href="css/signup.css"/>
<script src="scripts/loginvalid.js"></script>
	 <!--End Of Validation Script-->
<script src="scripts/emailpassvalid.js"></script>
    <meta charset="UTF-8">
</head>
<body>


<div class="modal fade" id="Failed" role="dialog">
    <div class="modal-dialog">
    
     
      <div class="modal-content">
        
        <div class="modal-body">
        	<!--Dynamic paragraph which takes value from php variable-->
          <p id="msg"  class="text-primary text-center"></p>
        </div>
        
      </div>
      
    </div>
  </div>


  <!--
===============================================================================
Php code for checking conditions user status for Registration
-->
<?php 
  					/*
						if condition for multiple status 
  					*/
                        if(isset($_GET['status']) AND $_GET['status']=="emailexist")
                        {
                          $message="This email is Taken by another user";
                             
                        }
                       


                     ?>

<script>
$( document ).ready(function() {
	/*  id for message in paragraph */
    $("#msg").html("<?php echo $message; ?>");
    /*
id of status which is coming from header location in php 
    */
    $('#Failed').modal('show'); 
    setTimeout("$('#Failed').modal('hide'); ", 4000); 

});
</script>





    <div class="container" style="margin:15px;">
         <img class="rounded mx-auto d-block" src="assets/deeplogo.jpeg" alt="" width="100" height="100">
           
          <h3 class="text-center">REGISTER</h3>
        <main class="form-signin">
            <form id="registerForm" action="reg_sub.php" method="POST" onsubmit="return checkUser();" enctype="multipart/form-data">
            <div class="form-floating mb-2">
              <input id="fname" placeholder="Enter First Name" name="fname" pattern="^[a-zA-Z\s]*$" title="Only letters are required" autocomplete="off" minlength="3" type="text"  class="form-control" required>
              <label for="userInput">First Name</label>
              <div id="firstnamechk" class="popup_error"></div>	
            </div>
            <div class="form-floating mb-2">
              <input id="lname" placeholder="Enter Last Name" name="lname" pattern="^[a-zA-Z\s]*$" title="Only letters are required" autocomplete="off" minlength="3" type="text"  class="form-control" required>
              <label for="userInput">Last Name</label>
              <div id="lastnamechk" class="popup_error"></div>	
            </div>
            <div class="form-floating mb-2">
              <input  id="emailInput" type="email"  id="email" placeholder="den.empower@gmail.com" name="email" onkeyup="checkemail();" pattern="[aA-zZ0-9._%+-]+@[aA-zZ0-9.-]+\.[aA-zZ]{2,3}$" title="Email should like den.empower@gmail.com" autocomplete="off"  class="form-control" required>
              <label for="emailInput">Email address</label>
              <div id="chkemail" class="popup_error"></div>
            </div>
            <div class="form-floating mb-2">
              <input id="passwordInput" type="password"  id="pass" placeholder="Enter Password" name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" class="form-control" required>
              <label for="passwordInput">Password</label>
              <div id="chkpwd" class="popup_error"></div>
            </div>
            <div class="form-floating mb-2">
              <input type="password" class="form-control" id="cpass" placeholder="Enter Confirm Password" name="cpass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" onkeyup="checkConfPass();" required>
              <label for="cpasswordInput">Confirm Password</label>
              <div id="cpwd" class="popup_error"></div>
            </div>

            
          
          <div class="card-footer text-center">
          <label for="checkbox">Already a User?
             <a href="signin.php">Sign in</label>
             <hr>
          <div class="checkbox">
            <input type="checkbox" id="checkbox" name="checkbox" required>
            <label for="checkbox">By signing up, you agree to the
             <a href="#">Term of Service</label>
          </div> 
        </div>

        <div class="text-center mb-5 mt-4">
              <button   name="submit" class="btn btn-outline-info" type="submit">REGISTER</button>
            </div>
          </form>
        </main>
    </div>





 <!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js'></script>
<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>
<script src='https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js'></script>
<script src='https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js'></script><script  src="./script.js"></script>   

</body>

</html>