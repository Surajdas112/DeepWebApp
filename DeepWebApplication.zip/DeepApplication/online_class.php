<?php
session_start();
ob_start();
include('inc/connection.php');

if(isset($_SESSION['email']) && !empty($_SESSION['email']) && isset($_SESSION['password']) && !empty($_SESSION['password']) ){
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Deep IAS Coaching</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css'>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css'>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/dashboardButton.css" />
  <link rel="stylesheet" href="css/dashboardTable.css" />
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <link rel="stylesheet" href="css/accountstyle.css">



  <script type="text/javascript">
    function onlineTest(){
      window.location.href = "online_test.php"; 
    }

    function onlineClass(){
      window.location.href = "online_class.php";  
    }
    function practiceTest(){
      window.location.href = "practice_test.php"; 
    }
</script>

</head>

<body>
  <!-- partial:index.partial.html -->
  <nav class="navbar navbar-expand-custom navbar-mainbg">
      <img class="logoimage" src="assets/deeplogo.png" alt="" width="50" height="50"><a class="navbar-brand navbar-logo" href="#">Deep IAS</a></img>

      <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="width:60px; height:60px;">
        <i id="menu-bars" class="fas fa-bars text-white"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent" style="position: relative;right:0px;">
        <ul class="navbar-nav ml-auto">
          <div class="hori-selector">
            <div class="left"></div>
            <div class="right"></div>
          </div>
          <li class="nav-item">
            <a class="nav-link" style="color:white;" href="index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
          </li>
          <li class="nav-item  active">
            <a class="nav-link" style="color:white;" href="online_class.php"><i class="fas fa-house-user"></i>Online Class</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:white;" href="test_categories.php"><i class="far fa-clone"></i>Online Test</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:white;" href="practice_test_categories.php"><i class="far fa-calendar-alt"></i>Practice Test</a>
          </li>


        </ul>

      </div>
      <div class="navigation">
        <div class="user-box">
          <div class="image-box">
            <img src="assets/deeplogo.png" alt="avatar">
          </div>
          <p class="username" style="font-size:1.5rem; margin-top:15px;"><?php echo $_SESSION['fname'] . " " . $_SESSION['lastname']; ?></p>
        </div>
        <div class="menu-toggle"></div>
        <ul class="menu">
          <li><a href="#">
              <ion-icon name="person-outline"></ion-icon>Profile
            </a></li>
          <li><a href="#">
              <ion-icon name="chatbox-outline"></ion-icon>Messages
            </a></li>
          <li><a href="#">
              <ion-icon name="notifications-outline"></ion-icon>Notification
            </a></li>
          <li><a href="#">
              <ion-icon name="cog-outline"></ion-icon>
              </ion-icon>Settings
            </a></li>
          <li><a href="logout.php">
              <ion-icon name="log-out-outline"></ion-icon>Logout
            </a></li>
        </ul>
      </div>

    </nav>





  <!--BODY STARTS FROM HERE-->
  <main  >
  
    

    

    <div class="IFRAMEcontainer" >
       <iframe class="responsive-iframe" src="https://www.youtube.com/embed/VKUw27wzY78"></iframe>
    </div>
  
</main>
    <!--BODY ENDS HERE-->





    <!-- partial -->
    <script src='https://code.jquery.com/jquery-3.4.1.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css'></script>
    <script src="./scripts/script.js"></script>





</body>

</html>

<?php

            
}
else{
  ?>
					<script>
					alert('Please Login');
					window.location.href='signin.php';
					</script>";
									
				<?php
}          
            
            

?>