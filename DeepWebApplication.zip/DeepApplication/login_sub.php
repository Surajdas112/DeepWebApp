<?php
session_start();
ob_start();
include('inc/connection.php');

if (isset($_POST['login'])) {

	$email = $_POST['email'];
	$pass = $_POST['pass'];

	$select_query = "SELECT * FROM register WHERE email='$email' and pass='$pass'";
	$res = mysqli_query($conn, $select_query);
	$row = mysqli_fetch_array($res);
	if (mysqli_num_rows($res) > 0) {
		$_SESSION['email'] = $email;
		$_SESSION['password'] = $pass;
		$_SESSION['fname'] = $row['fname'];
		$_SESSION['lastname'] = $row['lname'];
		$_SESSION['id'] = $row['id'];
		$_SESSION['image'] = $row['image'];
		$_SESSION['rollno'] = $row['rollno'];




		header('location:index.php');
	} else {
?>
		<script>
			alert('Invalid Username or Password');
			window.location.href = 'signin.php';
		</script>";
	<?php

	}
}

//// Forgot pass Code 

elseif (isset($_POST['resetpass'])) {


	?>

	<!doctype html>
	<html lang="en-US">

	<head>
		<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
		<title>Deep IAS</title>
		<meta name="description" content="Reset Password Email ">
		<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
 		 <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css'>
 	 <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css'>
	  <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css'></script>
   
		<style type="text/css">
			a:hover {
				text-decoration: underline !important;
			}
		</style>
	</head>

	<body marginheight="0" topmargin="0" marginwidth="0" style="margin: 0px; background-color: #f2f3f8;" leftmargin="0">
		<!--100% body table-->
		<table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8" style="@import url(https://fonts.googleapis.com/css?family=Rubik:300,400,500,700|Open+Sans:300,400,600,700); font-family: 'Open Sans', sans-serif;">
			<tr>
				<td>
					<table style="background-color: #f2f3f8; max-width:670px;  margin:0 auto;" width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
						<tr>
							<td style="height:80px;">&nbsp;</td>
						</tr>
						<tr>
							<td style="text-align:center;">
								<img width="100" src="assets/deeplogo.png" title="logo" alt="logo">
								</a>
							</td>
						</tr>
						<tr>
							<td style="height:20px;">&nbsp;</td>
						</tr>
						<tr>
							<td>
								<table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" style="max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);">
									<tr>
										<td style="height:40px;">&nbsp;</td>
									</tr>
									<tr>
										<td style="padding:0 35px;">
											<h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:32px;font-family:'Rubik',sans-serif;">You have
												requested to reset your password</h1>
											<span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;"></span>
											<form id="register-form"  action="forgetpassword.php" role="form" autocomplete="off" class="form" method="post">
												<div class="form-group">
													<input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
												</div>
												<div class="form-group">
													<input name="recover-submit" class="btn btn-lg btn-primary btn-block" value="Reset Password" type="submit">
												</div>

												<input type="hidden" class="hide" name="token" id="token" value="">
											</form>

										</td>
									</tr>
									<tr>
										<td style="height:40px;">&nbsp;</td>
									</tr>
								</table>
							</td>
						<tr>
							<td style="height:20px;">&nbsp;</td>
						</tr>
						<tr>

						</tr>
						<tr>
							<td style="height:80px;">&nbsp;</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<!--/100% body table-->
	</body>

	</html>



<?php




}

// Forgot pass Code
?>