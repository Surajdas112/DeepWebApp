<?php
session_start();
ob_start();
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Deep IAS</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <link rel="stylesheet" href="css/verification-email.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/prefixfree/1.0.7/prefixfree.min.js"></script>

  

</head>
<body>
<!-- partial:index.partial.html -->
<div class="c-email">  
  <div class="c-email__header">
  <img href="index.php" class="logo" src="assets/deeplogo.jpeg" style="margin-left:42%;height: 100px;width: 100px;border-radius: 200%;"></i>
    <h1 class="c-email__header__title">Your Verification Code  is sent on your mail</h1>
    <p style="color:white;" class="c-email__header__title"><?php echo @$_SESSION['user_email']?></p>
  </div>
  <div class="c-email__content">
    
    <div class="c-email__code">
  
    <form action="verify-email-process.php" class="row d-flex justify-content-center" method="post" >
   
  <div class="row">
   <span>
    <input class="slide-up otp" type="number" name="otp" id="otp security"   placeholder="Enter OTP Here"/><label for="security">Verification Code</label>
  </span>
  </div>
   
   <hr class="mt-4">
 <input   class="c-email__code__text" type="submit" id="emailotp" name="emailotp" class='btn btn-primary btn-block  customBtn'>

 </form>
     
    </div>
    
  </div>
  <div class="c-email__footer"></div>
</div>
<!-- partial -->
  <script  src="./script.js"></script>

</body>
</html>
