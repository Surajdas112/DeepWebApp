<?php
session_start();
include('inc/connection.php');

$coinQuery = "SELECT SUM(`is_correct`) as Correct, SUM(`is_notCorrect`) as Incorrect FROM `practice_test_answers` WHERE `rollno`='".trim($_SESSION['rollno'])."'";
$coin_res = mysqli_query($conn, $coinQuery);
if (mysqli_num_rows($coin_res) > 0) {

  $your_coins = mysqli_fetch_assoc($coin_res);
  
   
}





        $your_coins['Correct']; 
        $your_coins['Incorrect']; 


      
       
      //  $result = filter_input ( INPUT_GET , 'success' );
      //  if (isset($result) && !empty($result)) {
      //      echo '<img src="/opt/lampp/htdocs/DeepWebApp02-07-2022/success'.$result.'.gif">';
      //  }
       


       $myAudioFile = "coin.mp3";
echo '<audio autoplay="true" style="display:none;">
         <source src="'.$myAudioFile.'" type="audio/mp3">
      </audio>';



       
       ?>
       
       <script type="text/javascript">
         function restart() {
           window.location.replace('index.php');
         }
       </script>


<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Deep IAS</title>
  <meta name="viewport" content="width=device-width, initial-scale=1"><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="css/sess_score_style.css">
<linkrel="stylesheet" href="css/dashboardTable.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="wrapper">
    <div class="modal modal--congratulations">
        <div class="modal-top">
            <img class="modal-icon u-imgResponsive" height="150" width="150" src="assets/coin.gif" alt="Trophy" />
            <div class="modal-header">Congratulations! <br/> You have Earned <?php  echo (int)$your_coins['Correct']+(int)$your_coins['Incorrect']; ?> Coins</div>
            

            


      <table class="rwd-table">
      <tr>
          <th >Questions</th>
					<th>Correct</th>
					<th>Incorrect</th>
					<th>Not Attempted</th>
					<th>Final Score</th>
      
      </tr>
       <tr>
          <td data-th="Questions"><?php echo $_SESSION['qcount']; ?></td>
					<td data-th="Correct"><?php echo $_SESSION['right']; ?></td>
					<td data-th="Incorrect"><?php echo $_SESSION['wrong']; ?></td>
					<td data-th="Not Attempted"><?php echo $_SESSION['skip']; ?></td>
					<td data-th="Final Score"><?php echo  $_SESSION['right'] * 4 - $_SESSION['wrong']; ?></td>
      </tr>

    </table>



            
        </div>
        <div class="modal-bottom">
            <button class="modal-btn u-btn u-btn--share">Share</button>
            <button class="modal-btn u-btn u-btn--success" onclick="restart()">Go Back</button>
        </div>
    </div>
</div>
</body>
</html>

  

