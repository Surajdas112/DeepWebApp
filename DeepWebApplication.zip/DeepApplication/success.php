<?php

if (!isset($_SESSION['qcount'])) { 
    
    session_start();
    
  
    
    
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>


<style>
body, html {
  height: 100%;
  margin: 0;
}

.bg {
  /* The image used */
  background-image: url("success.gif");






  /* Full height */
 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>
</head>
<body style="text-align:center";>
    
       
     <div ><h2>Yay! Bulls Eye</h2></div>

<div  class="container" style="display: flex; justify-content: center; align-items: center; " >
    
   
  <div class="row">
      <img src="success.gif" style="height:350px; width: 500px;">
      
  </div><br/><br/>
<br/>  
  

</div>





</body>
</html>




<?php 
include('inc/connection.php');





$myAudioFile = "tada.wav";
echo '<audio autoplay="true" style="display:none;">
         <source src="'.$myAudioFile.'" type="audio/wav">
      </audio>';




if($_SESSION['qcount'] >= 10){
 
 
 echo "<script>window.location.replace('sess_score.php');</script>";



}else {
  echo "<script>setTimeout(function () {
window.location.href= 'newRough.php'; // the redirect goes here

},1500);</script>";

}



?>