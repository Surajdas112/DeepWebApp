<?php
session_start();
ob_start();
include('inc/connection.php');

if(isset($_POST) && !empty($_POST)){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $sql = "SELECT * FROM `register` WHERE email = '$email'";
    $res = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($res);
    if($count == 1){
        $r = mysqli_fetch_assoc($res);
        $password = $r['pass'];
        $to = $r['email'];
        $subject = "Your Recovered Password";
        $message = "Please use this password to login " . $password;
        $headers = "From : noreply@mart.denpower.org";
        if(mail($to, $subject, $message, $headers)){
          echo "Your Password has been sent to your email id";
        }else{
          echo "Failed to Recover your password, try again";
        }
      }else{
        echo "Email does not exist in database";
      }
  } 

?>