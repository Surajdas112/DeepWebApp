<?php
include('inc/connection.php');
@session_start();

if(isset($_SESSION['email']) && !empty($_SESSION['email']) && isset($_SESSION['password']) && !empty($_SESSION['password']) ){

if(isset($_POST['cat'])){


  $_SESSION['selectedcat'] = $_POST['cat'];
}




$select_category="SELECT subject_name FROM `subject` WHERE id='".$_SESSION['selectedcat']."'";


$catres=mysqli_query($conn,$select_category);
if(mysqli_num_rows($catres)>0){

	$YourCATEGORY=mysqli_fetch_assoc($catres);	
	$_SESSION['selected_catName']=$YourCATEGORY['subject_name'];



    
    

  }






if (isset($_SESSION["currentQuestion"]) && !empty($_SESSION["currentQuestion"])) {


  
    

    $quesList = "SELECT * FROM `online_test_questions` WHERE subject_id = '".$_SESSION['selectedcat']."' AND id =".$_SESSION["currentQuestion"];


    $res = mysqli_query($conn, $quesList);
    if (mysqli_num_rows($res) > 0) {

        
        $rs = mysqli_fetch_assoc($res);

        $_SESSION['qid'] =  $rs['question_id'];
        $_SESSION['correctAnswer'] =  $rs['ans'];


         
?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Deep IAS Coaching</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css'>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css'>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/dashboardButton.css" />

</head>

<body style="font-size:larger;">
  <!-- partial:index.partial.html -->
  <nav class="navbar navbar-expand-custom navbar-mainbg">
    <img class="logoimage" src="assets/deeplogo.png" alt="" width="50" height="50"><a class="navbar-brand navbar-logo" href="#">Deep IAS</a></img>

    <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fas fa-bars text-white"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <div class="hori-selector">
          <div class="left"></div>
          <div class="right"></div>
        </div>
        <li class="nav-item ">
            <a class="nav-link" style="color:white;" href="index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:white;"  href="online_class.php"><i class="fas fa-house-user"></i>Online Class</a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" style="color:white;" href="test_categories.php"><i class="far fa-clone"></i>Online Test</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" style="color:white;"  href="practice_test_categories.php"><i class="far fa-calendar-alt"></i>Practice Test</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" style="color:white;" href="logout.php"><i class="fa-solid fa-arrow-right-from-bracket"></i>Logout</a>
          </li>


      </ul>
    </div>
  </nav>

  <!--BODY STARTS FROM HERE-->
  <main>
  <div class="container" style="width:98%">
    <header class="pb-3  border-bottom" >
    <div class="row" >
      <div class="col"  >
          <span><?php echo @$_SESSION['selected_catName']; ?></span>
            <span  style="padding-left:20px;"><?php echo $_COOKIE['roll'] = $_SESSION['rollno']; ?></span>
            <span  style="padding-left:20px;"id="timer" >Time:</span>
      
      </div>
      
    </div>
    </header>
    <div class="row">
  <div class="col-md-9" style="text-align:justify; border: 1px solid #13AEB0;" >
              <form action="online_test_answer_evaluation.php" method="post" id="quiz">
                                <table style="width:100%;">
                                   
                                   <tr>
                                       
                                       <?php 
                                       
                                       //Get The Correct Answwer from the Question Table and Store it as Session Variable to Store Scores
                                       $_SESSION['correctAnswer'] = $rs['ans'];
                                       
                                       ?>

                                       <td class="qcontain"><?php echo $rs['question']; ?></td>

                                   </tr>
                                   <td>
                                    <hr>

                                       <input type="radio" value="<?php echo $rs['ans1']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp <?php echo $rs['ans1']; ?>
                                       <input type="radio" value="<?php echo $rs['ans2']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans2']; ?>
                                       <input type="radio" value="<?php echo $rs['ans3']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans3']; ?>
                                       <input type="radio" value="<?php echo $rs['ans4']; ?>" name="<?php echo $rs['id']; ?>" />&nbsp<?php echo $rs['ans4']; ?>



                                   </td>
                                   <td></td>
                                   <td></td>
                                
                               </table>
                              <div style="margin:10px;"> 
                              <input  style="margin-left:50px;" type="submit" value="Next"  class="btn btn-info" name="next">
                               <input style="margin-left:50px;"type="submit" value="Skip" class="btn btn-info" name="skip"></div>
                               


   
   
  </div>
  <div class="col-md-3">
    
     <!--Question Navigator-->
                            <div class="container qnav justify-content-between" style="height: 500px;overflow-y: scroll;">
                            <h6 >Question Navigator</h6>
                                <button type="submit" name="button1"  class="btn btn-outline-primary" style="font-size:10px;">1</button>                                                                                                                             
                                <button type="submit" name="button2"  class="btn btn-outline-primary" style="font-size:10px;">2</button>
                                <button type="submit" name="button3"  class="btn btn-outline-primary"style="font-size:10px;">3</button>
                                <button type="submit" name="button4"  class="btn btn-outline-primary"style="font-size:10px;">4</button>
                                <button type="submit" name="button5"  class="btn btn-outline-primary"style="font-size:10px;">5</button>
                                <button type="submit" name="button6"  class="btn btn-outline-primary"style="font-size:10px;">6</button>
                                <button type="submit" name="button7"  class="btn btn-outline-primary"style="font-size:10px;">7</button>
                                <button type="submit" name="button8"  class="btn btn-outline-primary"style="font-size:10px;">8</button>
                                <button type="submit" name="button9"  class="btn btn-outline-primary"style="font-size:10px;">9</button>
                                <button type="submit" name="button10"  class="btn btn-outline-primary"style="font-size:10px;">10</button>
                                <button type="submit" name="button11"  class="btn btn-outline-primary"style="font-size:10px;">11</button>
                                <button type="submit" name="button12"  class="btn btn-outline-primary"style="font-size:10px;">12</button>
                                  <button type="submit" name="button13"  class="btn btn-outline-primary"style="font-size:10px;">13</button>
                                <button type="submit" name="button14"  class="btn btn-outline-primary"style="font-size:10px;">14</button>
                                <button type="submit" name="button15"  class="btn btn-outline-primary"style="font-size:10px;">15</button>
                                <button type="submit" name="button16"  class="btn btn-outline-primary"style="font-size:10px;">16</button>
                                <button type="submit" name="button17"  class="btn btn-outline-primary"style="font-size:10px;">17</button>
                                <button type="submit" name="button18"  class="btn btn-outline-primary"style="font-size:10px;">18</button>
                                <button type="submit" name="button19"  class="btn btn-outline-primary"style="font-size:10px;">19</button>
                                <button type="submit" name="button20"  class="btn btn-outline-primary"style="font-size:10px;">20</button>
                                <button type="submit" name="button21"  class="btn btn-outline-primary"style="font-size:10px;">21</button>
                                <button type="submit" name="button22"  class="btn btn-outline-primary"style="font-size:10px;">22</button>
                                <button type="submit" name="button23"  class="btn btn-outline-primary"style="font-size:10px;">23</button>
                                <button type="submit" name="button24"  class="btn btn-outline-primary"style="font-size:10px;">24</button>
                                <button type="submit" name="button25"  class="btn btn-outline-primary"style="font-size:10px;">25</button>
                                <button type="submit" name="button26"  class="btn btn-outline-primary"style="font-size:10px;">26</button>
                                <button type="submit" name="button27"  class="btn btn-outline-primary"style="font-size:10px;">27</button>
                                <button type="submit" name="button28"  class="btn btn-outline-primary"style="font-size:10px;">28</button>
                                <button type="submit" name="button29"  class="btn btn-outline-primary"style="font-size:10px;">29</button>
                                <button type="submit" name="button30"  class="btn btn-outline-primary"style="font-size:10px;">30</button>
                                <button type="submit" name="button31"  class="btn btn-outline-primary"style="font-size:10px;">31</button>
                                <button type="submit" name="button32"  class="btn btn-outline-primary"style="font-size:10px;">32</button>
                                <button type="submit" name="button33"  class="btn btn-outline-primary"style="font-size:10px;">33</button>
                                <button type="submit" name="button34"  class="btn btn-outline-primary"style="font-size:10px;">34</button>
                                <button type="submit" name="button35"  class="btn btn-outline-primary"style="font-size:10px;">35</button>
                                <button type="submit" name="button36"  class="btn btn-outline-primary"style="font-size:10px;">36</button>
                                <button type="submit" name="button37"  class="btn btn-outline-primary"style="font-size:10px;">37</button>
                                <button type="submit" name="button38"  class="btn btn-outline-primary"style="font-size:10px;">38</button>
                                <button type="submit" name="button39"  class="btn btn-outline-primary"style="font-size:10px;">39</button>
                                <button type="submit" name="button40"  class="btn btn-outline-primary"style="font-size:10px;">40</button>
                                <button type="submit" name="button41"  class="btn btn-outline-primary"style="font-size:10px;">41</button>
                                <button type="submit" name="button42"  class="btn btn-outline-primary"style="font-size:10px;">42</button>
                                <button type="submit" name="button43"  class="btn btn-outline-primary"style="font-size:10px;">43</button>
                                <button type="submit" name="button44"  class="btn btn-outline-primary"style="font-size:10px;">44</button>
                                <button type="submit" name="button45"  class="btn btn-outline-primary"style="font-size:10px;">45</button>
                                <button type="submit" name="button46"  class="btn btn-outline-primary"style="font-size:10px;">46</button>
                                <button type="submit" name="button47"  class="btn btn-outline-primary"style="font-size:10px;">47</button>
                                <button type="submit" name="button48"  class="btn btn-outline-primary"style="font-size:10px;">48</button>
                                <button type="submit" name="button49"  class="btn btn-outline-primary"style="font-size:10px;">49</button>
                                <button type="submit" name="button50"  class="btn btn-outline-primary"style="font-size:10px;">50</button>
                                <button type="submit" name="button51"  class="btn btn-outline-primary"style="font-size:10px;">51</button>
                                <button type="submit" name="button52"  class="btn btn-outline-primary"style="font-size:10px;">52</button>
                                <button type="submit" name="button53"  class="btn btn-outline-primary"style="font-size:10px;">53</button>
                                <button type="submit" name="button54"  class="btn btn-outline-primary"style="font-size:10px;">54</button>
                                <button type="submit" name="button55"  class="btn btn-outline-primary"style="font-size:10px;">55</button>
                                <button type="submit" name="button56"  class="btn btn-outline-primary"style="font-size:10px;">56</button>
                                <button type="submit" name="button57"  class="btn btn-outline-primary"style="font-size:10px;">57</button>
                                <button type="submit" name="button58"  class="btn btn-outline-primary"style="font-size:10px;">58</button>
                                <button type="submit" name="button59"  class="btn btn-outline-primary"style="font-size:10px;">59</button>
                                <button type="submit" name="button60"  class="btn btn-outline-primary"style="font-size:10px;">60</button>
                                <button type="submit" name="button61"  class="btn btn-outline-primary"style="font-size:10px;">61</button>
                                <button type="submit" name="button62"  class="btn btn-outline-primary"style="font-size:10px;">62</button>
                                <button type="submit" name="button63"  class="btn btn-outline-primary"style="font-size:10px;">63</button>
                                <button type="submit" name="button64"  class="btn btn-outline-primary"style="font-size:10px;">64</button>
                                <button type="submit" name="button65"  class="btn btn-outline-primary"style="font-size:10px;">65</button>
                                <button type="submit" name="button66"  class="btn btn-outline-primary"style="font-size:10px;">66</button>
                                <button type="submit" name="button67"  class="btn btn-outline-primary"style="font-size:10px;">67</button>
                                <button type="submit" name="button68"  class="btn btn-outline-primary"style="font-size:10px;">68</button>
                                <button type="submit" name="button69"  class="btn btn-outline-primary"style="font-size:10px;">69</button>
                                <button type="submit" name="button70"  class="btn btn-outline-primary"style="font-size:10px;">70</button>
                                <button type="submit" name="button71"  class="btn btn-outline-primary"style="font-size:10px;">71</button>
                                <button type="submit" name="button72"  class="btn btn-outline-primary"style="font-size:10px;">72</button>
                                <button type="submit" name="button73"  class="btn btn-outline-primary"style="font-size:10px;">73</button>
                                <button type="submit" name="button74"  class="btn btn-outline-primary"style="font-size:10px;">74</button>
                                <button type="submit" name="button75"  class="btn btn-outline-primary"style="font-size:10px;">75</button>
                                <button type="submit" name="button76"  class="btn btn-outline-primary"style="font-size:10px;">76</button>
                                <button type="submit" name="button77"  class="btn btn-outline-primary"style="font-size:10px;">77</button>
                                <button type="submit" name="button78"  class="btn btn-outline-primary"style="font-size:10px;">78</button>
                                <button type="submit" name="button79"  class="btn btn-outline-primary"style="font-size:10px;">79</button>
                                <button type="submit" name="button80"  class="btn btn-outline-primary"style="font-size:10px;">80</button>
                                <!-- <button type="submit" name="button81"  class="btn btn-outline-pristyle="font-size:10px;"mary">81</button>
                                <button type="submit" name="button82"  class="btn btn-outline-primary"style="font-size:10px;">82</button>
                                <button type="submit" name="button83"  class="btn btn-outline-primary"style="font-size:10px;">83</button>
                                <button type="submit" name="button84"  class="btn btn-outline-primary"style="font-size:10px;">84</button>
                                <button type="submit" name="button85"  class="btn btn-outline-primary"style="font-size:10px;">85</button>
                                <button type="submit" name="button86"  class="btn btn-outline-primary"style="font-size:10px;">86</button>
                                <button type="submit" name="button87"  class="btn btn-outline-primary"style="font-size:10px;">87</button>
                                <button type="submit" name="button88"  class="btn btn-outline-primary"style="font-size:10px;">88</button>
                                <button type="submit" name="button89"  class="btn btn-outline-primary"style="font-size:10px;">89</button>
                                <button type="submit" name="button90"  class="btn btn-outline-primary"style="font-size:10px;">90</button>
                                <button type="submit" name="button91"  class="btn btn-outline-primary"style="font-size:10px;">91</button>
                                <button type="submit" name="button92"  class="btn btn-outline-primary"style="font-size:10px;">92</button>
                                <button type="submit" name="button93"  class="btn btn-outline-primary"style="font-size:10px;">93</button>
                                <button type="submit" name="button94"  class="btn btn-outline-primary"style="font-size:10px;">94</button>
                                <button type="submit" name="button95"  class="btn btn-outline-primary"style="font-size:10px;">95</button>
                                <button type="submit" name="button96"  class="btn btn-outline-primary"style="font-size:10px;">96</button>
                                <button type="submit" name="button97"  class="btn btn-outline-primary"style="font-size:10px;">97</button>
                                <button type="submit" name="button98"  class="btn btn-outline-primary"style="font-size:10px;">98</button>
                                <button type="submit" name="button99"  class="btn btn-outline-primary"style="font-size:10px;">99</button>
                                <button type="submit" name="button100"  class="btn btn-outline-primary"style="font-size:10px;">100</button> -->
                            </div>

  </div>

  </form>
</div>  
    
  </div>
</main>

  <!--BODY ENDS HERE-->





    <!-- partial -->
    <script src='https://code.jquery.com/jquery-3.4.1.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js'></script>
    <script src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css'></script>
    <script src="./scripts/script.js"></script>
    
</body>

</html>


<?php
        }else{
      header('Location:norecords.php');

        }
    
} else {
    $_SESSION["currentQuestion"] = 1;
}


?>

<?php

            
}
else{
  ?>
					<script>
					alert('Please Login');
					window.location.href='signin.php';
					</script>";
									
				<?php
}          
            
            

?>