<?php
include('inc/connection.php');
session_start();
ob_start();



if(isset($_POST['otp']) && !empty(isset($_POST['otp']))){
    
    $emailOtp =  (int)$_POST['otp'];

    echo  $emailOtp;
    $otp_query = "SELECT * FROM `register` WHERE email='".trim($_SESSION['user_email'])."' AND otp=".$emailOtp;
	$query_res = mysqli_query($conn,$otp_query);
    if (mysqli_num_rows($query_res) > 0) {

            

		$result = "UPDATE `register` SET `approve` = 1 WHERE otp =".$emailOtp;
		
        $otp_res = mysqli_query($conn,$otp_query);
     if (mysqli_num_rows($otp_res) > 0) {

       

        ?>
        <script>
        alert('Your Email has been verfied Sucessfully');
        window.location.href='signin.php';
        </script>";
                        
    <?php
        
        
	} else {
        header('location:verify-email.php');
	}	
    
}else{

                 ?>
					<script>
					alert('You have entered wrong OTP');
					window.location.href='verify-email.php';
					</script>";
									
				<?php
}

}
else{

    header('location:verify-email.php');
}







?>