<?php
session_start();
ob_start();
include('inc/connection.php');

if(isset($_POST['resetpass'])){


echo "Hpw can you for get your pass";

}



?>